from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

def llm_predict_lien_necessity(cheque_data: dict, llm: ChatOpenAI) -> (bool, str):
    """
    Uses an LLM to perform a risk assessment and predict if a lien is needed.
    """
    print("INFO: Predicting lien necessity using LLM...")

    prompt_template = ChatPromptTemplate.from_messages([
        ("system", "You are a banking risk analyst. Your job is to decide if a lien should be placed on an account based on a pending cheque transaction. High amounts are a key factor."),
        ("human", """
        A cheque with the following details is being processed:
        - Amount: ${amount}
        - Payee: {payee}
        - Account Number: {account_number}
        
        Based on general banking risk principles, does this transaction warrant placing a temporary lien on the account?
        Consider the amount. A very large amount (e.g., > $10,000) is a strong indicator for a lien.
        
        Respond with a JSON object with two keys:
        - "predict_lien": boolean
        - "reason": string (Justify your decision in one sentence)
        """)
    ])
    
    chain = prompt_template | llm
    cheque_data_with_defaults = {
        "amount": cheque_data.get("amount", 0.0),
        "payee": cheque_data.get("payee", "N/A"),
        "account_number": cheque_data.get("account_number", "N/A"),
    }
    response = chain.invoke(cheque_data_with_defaults)
    
    print(f"DEBUG: LLM Lien Prediction Response: {response.content[:100]}...")
    if "true" in response.content.lower():
        return True, "LLM recommends lien based on risk assessment."
    return False, "LLM determined a lien is not necessary."