import pandas as pd
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

def llm_analyze_historical_behavior(cheque_data: dict, historical_data: pd.DataFrame, llm: ChatOpenAI) -> (bool, str):
    """
    Uses an LLM to analyze cheque data against historical context for anomalies.
    """
    print("INFO: Analyzing historical behavior using LLM...")
    account_id = cheque_data.get("account_number")
    amount = cheque_data.get("amount")

    if not (account_id and amount):
        return False, "Insufficient data for behavior analysis."

    user_transactions = historical_data[historical_data['account_id'] == account_id]
    
    if user_transactions.empty:
        return False, "No historical data for this account."

    history_summary = f"""
    - Average transaction amount: ${user_transactions['amount'].mean():.2f}
    - Maximum transaction amount: ${user_transactions['amount'].max():.2f}
    - Transaction count in last 30 days: {len(user_transactions)}
    - Frequent Payees: {list(user_transactions['payee'].value_counts().head(3).index)}
    """
    
    prompt_template = ChatPromptTemplate.from_messages([
        ("system", "You are a fraud detection analyst. Your task is to determine if a new transaction is anomalous based on historical data."),
        ("human", """
        Here is the historical transaction summary for an account:
        {history}

        And here is the new cheque transaction to analyze:
        - Amount: ${amount}
        - Payee: {payee}

        Is this transaction unusual or potentially fraudulent? Provide a brief justification.
        Respond with a JSON object with two keys:
        - "is_anomalous": boolean
        - "reason": string
        """)
    ])

    chain = prompt_template | llm
    response = chain.invoke({
        "history": history_summary,
        "amount": amount,
        "payee": cheque_data.get("payee", "N/A")
    })

    print(f"DEBUG: LLM Behavior Analysis Response: {response.content[:100]}...")
    if "true" in response.content.lower():
        return True, "LLM flagged transaction as behaviorally anomalous."
    return False, "LLM determined transaction is within normal behavioral patterns."