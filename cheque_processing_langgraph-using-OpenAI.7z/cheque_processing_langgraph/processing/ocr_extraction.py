import base64
import cv2
import numpy as np
import json
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI

def encode_image_for_llm(image: np.ndarray) -> str:
    """Encodes a CV2 image to a base64 string."""
    _, buffer = cv2.imencode('.png', image)
    return base64.b64encode(buffer).decode('utf-8')

def llm_extract_cheque_data(image: np.ndarray, llm: ChatOpenAI) -> dict:
    """
    Uses a multimodal LLM to extract structured data from a cheque image.
    """
    print("INFO: Extracting data using multimodal LLM...")
    base64_image = encode_image_for_llm(image)

    prompt = HumanMessage(
        content=[
            {"type": "text", "text": """
            You are a highly accurate OCR and data extraction AI.
            Extract the following information from the attached cheque image:
            - payee (string)
            - amount (float)
            - date (string, in MM/DD/YYYY format)
            - account_number (string)
            
            Return the information as a single JSON object. If a field is not visible, use null as its value.
            Example: {"payee": "John Smith", "amount": 150.75, "date": "07/20/2025", "account_number": "123456789"}
            Only respond with the JSON object.
            """},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
        ]
    )

    try:
        response = llm.invoke([prompt])
        json_str_match = response.content[response.content.find('{'):response.content.rfind('}')+1]
        data = json.loads(json_str_match)
        if not data.get("account_number"):
            data["account_number"] = "ACC12345" # Fallback for demo
        return data
    except Exception as e:
        print(f"ERROR: Failed to parse LLM response for data extraction: {e}")
        return {"error": str(e)}