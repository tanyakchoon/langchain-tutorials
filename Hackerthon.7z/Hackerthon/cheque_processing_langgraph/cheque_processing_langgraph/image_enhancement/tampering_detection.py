import base64
import cv2
import numpy as np
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI

def encode_image_for_llm(image: np.ndarray) -> str:
    """Encodes a CV2 image to a base64 string."""
    _, buffer = cv2.imencode('.png', image)
    return base64.b64encode(buffer).decode('utf-8')

def llm_detect_tampering(image: np.ndarray, llm: ChatOpenAI) -> (bool, str):
    """
    Uses a multimodal LLM to analyze an image for signs of tampering.
    """
    print("INFO: Analyzing for tampering using multimodal LLM...")
    base64_image = encode_image_for_llm(image)

    prompt = HumanMessage(
        content=[
            {
                "type": "text",
                "text": """You are a forensic document examiner. Analyze the attached cheque image for any signs of tampering.
                Look for:
                1. Mismatched fonts in the payee name or amount.
                2. Smudges, discoloration, or alignment issues in the amount fields.
                3. Any visual anomalies that suggest the cheque has been altered.
                
                Respond with a JSON object containing two keys:
                - "is_tampered": boolean (true if you suspect tampering, false otherwise)
                - "reason": string (a brief explanation of your findings)
                
                Only respond with the JSON object.
                """,
            },
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/png;base64,{base64_image}"},
            },
        ]
    )

    response = llm.invoke([prompt])
    # Placeholder for actual response parsing
    print(f"DEBUG: LLM Tampering Analysis Response: {response.content[:100]}...")
    if "true" in response.content.lower():
        return True, "LLM analysis suggests potential tampering."
    return False, "LLM analysis found no obvious signs of tampering."