from typing import TypedDict, List
import uuid
import numpy as np
import cv2
import pandas as pd
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
import os

# Adjust imports to be relative
from .image_enhancement.enhancer import enhance_brightness_contrast, correct_skew, llm_check_readability
from .processing.ocr_extraction import llm_extract_cheque_data
from .processing.validation import validate_account_details, trigger_lien_marking
from .fraud_detection.tampering_detection import llm_detect_tampering
from .fraud_detection.behavior_analysis import llm_analyze_historical_behavior
from .predictive_lien.predictor import llm_predict_lien_necessity
from .audit.trail import AuditTrail


class ChequeState(TypedDict):
    image_path: str
    image: np.ndarray
    cheque_data: dict
    audit_trail: AuditTrail
    is_readable: bool
    fraud_detected: bool
    final_decision: str
    feedback: List[str]


def build_graph():
    """Builds and returns the LangGraph compiled workflow."""
    load_dotenv()
    
    multimodal_llm = ChatOpenAI(model="gpt-4o", temperature=0)
    text_llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)
    
    historical_transactions = pd.DataFrame({
        'account_id': ['ACC12345', 'ACC12345', 'ACC98765'],
        'amount': [150.00, 250.50, 3000.00],
        'payee': ['utility co', 'rentals inc', 'car dealership']
    })

    # Graph Nodes
    def start_processing(state: ChequeState) -> ChequeState:
        image_path = state["image_path"]
        cheque_id = f"cheque-{uuid.uuid4().hex[:8]}"
        audit_trail = AuditTrail(cheque_id)
        try:
            image = cv2.imread(image_path)
            if image is None: raise FileNotFoundError(f"Image not found at {image_path}")
            audit_trail.log_step("Start", "Success", "Image loaded.")
            return {**state, "image": image, "audit_trail": audit_trail, "feedback": []}
        except Exception as e:
            audit_trail.log_step("Start", "Failed", str(e))
            return {**state, "audit_trail": audit_trail, "feedback": [str(e)], "final_decision": "REJECT"}

    def check_image_quality(state: ChequeState) -> ChequeState:
        audit_trail = state["audit_trail"]
        is_readable, msg = llm_check_readability(state["image"], multimodal_llm)
        if not is_readable:
            audit_trail.highlight_anomaly("Image Quality", msg)
            state["feedback"].append("LLM rejected image quality.")
            return {**state, "is_readable": False}
        
        audit_trail.log_step("Image Quality Check", "Success", "LLM approved image quality.")
        image = enhance_brightness_contrast(state["image"])
        image = correct_skew(image)
        audit_trail.log_step("Image Enhancement", "Success", "Image enhanced and skew-corrected.")
        return {**state, "is_readable": True, "image": image}

    def extract_data(state: ChequeState) -> ChequeState:
        audit_trail = state["audit_trail"]
        data = llm_extract_cheque_data(state["image"], multimodal_llm)
        if "error" in data or not data.get("amount"):
            err_msg = data.get("error", "LLM failed to extract key fields.")
            audit_trail.log_step("OCR Extraction", "Failed", err_msg)
            state["feedback"].append(err_msg)
            return {**state, "final_decision": "MANUAL_REVIEW"}
        
        audit_trail.log_step("OCR Extraction", "Success", f"Extracted Amount: {data.get('amount')}")
        return {**state, "cheque_data": data}

    def run_fraud_detection(state: ChequeState) -> ChequeState:
        audit_trail = state["audit_trail"]
        fraud_found = False

        is_tampered, msg = llm_detect_tampering(state["image"], multimodal_llm)
        if is_tampered:
            audit_trail.highlight_anomaly("Tampering Detection", msg)
            fraud_found = True

        is_anomalous, msg = llm_analyze_historical_behavior(state["cheque_data"], historical_transactions, text_llm)
        if is_anomalous:
            audit_trail.highlight_anomaly("Behavior Analysis", msg)
            fraud_found = True
        
        audit_trail.log_step("Fraud Detection", "Completed", f"Fraud found: {fraud_found}")
        return {**state, "fraud_detected": fraud_found}

    def validate_and_process(state: ChequeState) -> ChequeState:
        audit_trail = state["audit_trail"]
        data = state["cheque_data"]
        is_valid, msg = validate_account_details(data["account_number"])
        if not is_valid:
            audit_trail.highlight_anomaly("Account Validation", msg)
            return {**state, "final_decision": "REJECT"}
        
        audit_trail.log_step("Account Validation", "Success", "Account is valid.")

        needs_lien, msg = llm_predict_lien_necessity(data, text_llm)
        if needs_lien:
            audit_trail.log_step("Lien Prediction", "Recommended", msg)
            success, lien_msg = trigger_lien_marking(data["account_number"], data["amount"])
            audit_trail.log_step("Lien Marking", "Success" if success else "Failed", lien_msg)

        state["feedback"].append("Cheque processed successfully.")
        return {**state, "final_decision": "APPROVE"}

    def route_after_quality_check(state: ChequeState):
        return "extract_data" if state["is_readable"] else END

    def route_after_extraction(state: ChequeState):
        return "run_fraud_detection" if "MANUAL_REVIEW" not in state.get("final_decision", "") else END

    def route_after_fraud_check(state: ChequeState):
        return "manual_review" if state["fraud_detected"] else "validate_and_process"

    workflow = StateGraph(ChequeState)
    workflow.add_node("start", start_processing)
    workflow.add_node("check_image_quality", check_image_quality)
    workflow.add_node("extract_data", extract_data)
    workflow.add_node("run_fraud_detection", run_fraud_detection)
    workflow.add_node("validate_and_process", validate_and_process)
    workflow.add_node("manual_review", lambda state: {**state, "final_decision": "MANUAL_REVIEW"})

    workflow.set_entry_point("start")
    workflow.add_edge("start", "check_image_quality")
    workflow.add_conditional_edges("check_image_quality", route_after_quality_check)
    workflow.add_conditional_edges("extract_data", route_after_extraction)
    workflow.add_conditional_edges("run_fraud_detection", route_after_fraud_check)
    workflow.add_edge("validate_and_process", END)
    workflow.add_edge("manual_review", END)

    return workflow.compile(), text_llm

def create_test_cheque_image():
    """Creates a dummy cheque image file for testing."""
    image_path = "test_cheque.png"
    if not os.path.exists(image_path):
        print(f"INFO: Creating dummy cheque image at {image_path}")
        dummy_image = np.full((800, 2000, 3), 255, dtype=np.uint8)
        cv2.putText(dummy_image, "Pay to the order of: John Doe", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (0,0,0), 3)
        cv2.putText(dummy_image, "$1234.56", (1500, 250), cv2.FONT_HERSHEY_SIMPLEX, 2, (0,0,0), 3)
        cv2.putText(dummy_image, "Date: 07/20/2025", (1500, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (0,0,0), 3)
        cv2.putText(dummy_image, "Acct: ACC12345", (50, 700), cv2.FONT_HERSHEY_SIMPLEX, 2, (0,0,0), 3)
        cv2.imwrite(image_path, dummy_image)
    return image_path

def main():
    """Main function to run the cheque processing workflow."""
    print("Initializing Cheque Processing System...")
    app, text_llm = build_graph()
    
    image_path = create_test_cheque_image()
    initial_state = {"image_path": image_path}
    
    print("\nStarting Cheque Processing Workflow...")
    final_state = app.invoke(initial_state)

    print("\n\n" + "="*50)
    print("           FINAL CHEQUE PROCESSING OUTCOME")
    print("="*50)
    print(f"Final Decision: {final_state.get('final_decision', 'N/A')}")
    print(f"Feedback: {final_state.get('feedback')}")
    print("\n--- LLM-Generated Audit Summary ---")
    summary = final_state["audit_trail"].generate_llm_summary_report(text_llm)
    print(summary)
    print("="*50)

if __name__ == "__main__":
    main()