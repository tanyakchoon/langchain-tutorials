import base64
import cv2
import numpy as np
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI

def encode_image_for_llm(image: np.ndarray) -> str:
    """Encodes a CV2 image to a base64 string."""
    _, buffer = cv2.imencode('.png', image)
    return base64.b64encode(buffer).decode('utf-8')

def correct_skew(image: np.ndarray) -> np.ndarray:
    """Corrects the skew of a cheque image."""
    print("INFO: Correcting image skew...")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.bitwise_not(gray)
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thresh > 0))
    angle = cv2.minAreaRect(coords)[-1]

    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle

    (h, w) = image.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated = cv2.warpAffine(image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    return rotated

def enhance_brightness_contrast(image: np.ndarray, alpha=1.5, beta=10) -> np.ndarray:
    """Enhances the brightness and contrast of the image."""
    print("INFO: Enhancing brightness and contrast...")
    return cv2.convertScaleAbs(image, alpha=alpha, beta=beta)

def llm_check_readability(image: np.ndarray, llm: ChatOpenAI) -> (bool, str):
    """
    Uses a multimodal LLM to check if the image is readable and provide feedback.
    """
    print("INFO: Checking image readability using multimodal LLM...")
    base64_image = encode_image_for_llm(image)
    
    prompt = HumanMessage(
        content=[
            {"type": "text", "text": """
            You are an image quality inspector for a cheque processing system.
            Assess the quality of the attached image. Is it clear, well-lit, and complete?
            Or is it blurry, skewed, dark, or cut off?
            
            Respond with a JSON object with two keys:
            - "is_readable": boolean (true if the quality is acceptable)
            - "feedback": string (a very brief, user-facing comment, e.g., "Image is too dark" or "Quality is good")
            """},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
        ]
    )

    response = llm.invoke([prompt])
    print(f"DEBUG: LLM Readability Response: {response.content[:100]}...")
    if "true" in response.content.lower():
        return True, "LLM determined image is readable."
    return False, "LLM flagged image as unreadable."