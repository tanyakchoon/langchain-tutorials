# Multi-Agent Cheque Processing System with LangGraph

This project demonstrates a multi-agent system for end-to-end cheque processing, built using the LangGraph framework. It leverages Large Language Models (LLMs) for complex tasks like fraud detection, data extraction, and audit summarization.

## Features

- **LLM-Enhanced Image Quality Check**: Uses a multimodal LLM to assess image readability before processing.
- **Advanced Data Extraction**: Employs an LLM to extract structured data (payee, amount, date) directly from the cheque image, replacing brittle regex.
- **Multi-faceted Fraud Detection**:
  - **Tampering**: A multimodal LLM "looks" for visual signs of alteration.
  - **Behavioral**: An LLM analyzes the transaction against historical data for anomalies.
- **Predictive Lien Management**: A risk-analyst LLM predicts the necessity of placing a lien on an account.
- **AI-Generated Audit Trail**: At the end of the process, an LLM generates a human-readable summary of the cheque's entire journey.

## Setup and Installation

### 1. Prerequisites
- Python 3.9+
- An OpenAI API key

### 2. Create Project Directory
Create the folder structure as described in the source documentation.

### 3. Set Up Your OpenAI API Key
Create a new file named `.env` in the root of the project directory. Add your OpenAI API key to this file:```
OPENAI_API_KEY="your-sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxx-api-key"