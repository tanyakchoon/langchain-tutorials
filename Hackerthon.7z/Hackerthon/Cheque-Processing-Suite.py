# Cheque Processing with Modular AI Agents using LangGraph

from langgraph.graph import StateGraph
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
from langgraph.pregel import State
import openai
import base64
import json
import gradio as gr
from PIL import Image

llm = ChatOpenAI(temperature=0)

# -------------------- Module 1: Cheque Fraud Detection --------------------
def fraud_detection_agent(state):
    fields = state["fields"]

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a fraud detection expert. Analyze image tampering, signature anomalies, and historical patterns."),
        ("human", "Given cheque data and image context:\n\n{fields}\n\nReturn JSON with 'fraudulent': true/false, 'reasons': list")
    ])

    chain = prompt | llm | StrOutputParser()
    response = chain.invoke({"fields": json.dumps(fields)})
    state["fraud"] = json.loads(response)
    return state

# -------------------- Module 2: Image Quality Enhancer --------------------
def enhance_image_agent(state):
    image_path = state["image_path"]

    client = openai.OpenAI()
    with open(image_path, "rb") as image_file:
        image_data = base64.b64encode(image_file.read()).decode("utf-8")

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are an AI image enhancer for cheques. Check clarity, contrast, and completeness."},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Enhance and assess image quality. Return JSON with 'enhanced': true/false and 'issues': list."},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_data}"}}
                ]
            }
        ],
        max_tokens=1000
    )

    state["image_quality"] = json.loads(response.choices[0].message.content)
    return state

# -------------------- Module 3: End-to-End Processing Assistant --------------------
def ocr_extract_agent(state):
    image_path = state["image_path"]

    with open(image_path, "rb") as image_file:
        image_data = base64.b64encode(image_file.read()).decode("utf-8")

    client = openai.OpenAI()

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are an OCR+NLP assistant for extracting cheque information."},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Extract payee, amount, date, account number, signature, and other metadata. Return JSON."},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_data}"}}
                ]
            }
        ],
        max_tokens=1000
    )

    state["fields"] = json.loads(response.choices[0].message.content)
    return state

def account_validation_agent(state):
    fields = state["fields"]
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a bank account validator."),
        ("human", "Validate account details in the following cheque data:\n\n{fields}\n\nRespond JSON with 'valid': true/false and 'errors': list")
    ])
    chain = prompt | llm | StrOutputParser()
    response = chain.invoke({"fields": json.dumps(fields)})
    state["validation"] = json.loads(response)
    return state

def lien_trigger_agent(state):
    fields = state["fields"]
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an API integrator for lien marking."),
        ("human", "Trigger lien marking for:\n\n{fields}\n\nRespond JSON with confirmation.")
    ])
    chain = prompt | llm | StrOutputParser()
    state["lien"] = json.loads(chain.invoke({"fields": json.dumps(fields)}))
    return state

# -------------------- Module 4: Predictive Lien Management --------------------
def predictive_lien_agent(state):
    fields = state["fields"]
    prompt = ChatPromptTemplate.from_messages([
        ("system", "Predict need for lien marking based on cheque patterns."),
        ("human", "Analyze cheque behavior:\n\n{fields}\n\nReturn JSON with 'predict_lien': true/false, 'confidence': %, and 'note'.")
    ])
    chain = prompt | llm | StrOutputParser()
    state["lien_prediction"] = json.loads(chain.invoke({"fields": json.dumps(fields)}))
    return state

# -------------------- Module 5: AI Audit Trail Generator --------------------
def audit_agent(state):
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an AI auditor generating traceable summaries."),
        ("human", "Summarize all steps in processing this cheque:\n\n{data}\n\nOutput human-readable audit log.")
    ])
    audit_data = json.dumps(state, indent=2)
    chain = prompt | llm | StrOutputParser()
    state["audit"] = chain.invoke({"data": audit_data})
    return state

# -------------------- LangGraph Workflow --------------------
def build_graph():
    graph = StateGraph(State)
    graph.set_entry_point("ENHANCE")

    graph.add_node("ENHANCE", enhance_image_agent)
    graph.add_node("OCR", ocr_extract_agent)
    graph.add_node("VALIDATE", account_validation_agent)
    graph.add_node("FRAUD", fraud_detection_agent)
    graph.add_node("LIEN_TRIGGER", lien_trigger_agent)
    graph.add_node("LIEN_PREDICT", predictive_lien_agent)
    graph.add_node("AUDIT", audit_agent)

    graph.add_edge("ENHANCE", "OCR")
    graph.add_edge("OCR", "VALIDATE")
    graph.add_edge("VALIDATE", "FRAUD")
    graph.add_edge("FRAUD", "LIEN_PREDICT")
    graph.add_edge("LIEN_PREDICT", "LIEN_TRIGGER")
    graph.add_edge("LIEN_TRIGGER", "AUDIT")

    return graph.compile()

# -------------------- Gradio UI --------------------
def process_cheque(image):
    image_path = "temp_cheque.png"
    image.save(image_path)
    graph = build_graph()
    result = graph.invoke({"image_path": image_path})
    return json.dumps(result, indent=2)

def main():
    with gr.Blocks() as demo:
        gr.Markdown("# 🧾 Multi-Agent Cheque Processing System")
        image_input = gr.Image(type="pil", label="Upload Cheque Image")
        output = gr.Textbox(label="Final Output", lines=30)
        btn = gr.Button("Run Processing")
        btn.click(process_cheque, inputs=image_input, outputs=output)
    demo.launch()

if __name__ == "__main__":
    main()
